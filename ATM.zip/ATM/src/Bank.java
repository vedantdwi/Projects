import java.util.ArrayList;
import java.util.Random;

public class Bank {
    private String name;
    private ArrayList<User> users;
    private ArrayList<Account> accounts;

    /**
     * Create a new Bank object with empty lists of users and accounts
     * @param name  the name of the Bank
     */
    public Bank(String name){
        this.name = name;
        this.users = new ArrayList<User>();
        this. accounts = new ArrayList<Account>();
    }

    /**
     * Generate a new universally unique Id for a user
     * @return   the uni_id
     */
    public String getNewUserUNI_ID() {

        //inits
        String uni_id;
        Random rng = new Random();
        int len = 6;
        boolean nonUnique;
        // continue looping until we get a unique Id
        do{
            // generate the number
            uni_id = "";
            for(int c = 0; c < len; c++){
                uni_id +=((Integer)rng.nextInt(10)).toString();
            }

            //check to make sure it's unique
            nonUnique = false;
            for(User u : this.users) {
                if(uni_id.compareTo(u.getUNI_ID()) == 0) {
                    nonUnique = true;
                    break;
                }
            }
        }while (nonUnique);

        return uni_id;
    }

    /**
     * Generate a new universally unique Id for an account
     * @return  the acc_id
     */
    public String getNewAccountACC_ID() {
        //inits
        String acc_id;
        Random rng = new Random();
        int len = 10;
        boolean nonUnique;
        // continue looping until we get a unique Id
        do{
            // generate the number
            acc_id = "";
            for(int c = 0; c < len; c++){
                acc_id +=((Integer)rng.nextInt(10)).toString();
            }

            //check to make sure it's unique
            nonUnique = false;
            for(Account a: this.accounts) {
                if(acc_id.compareTo(a.getACC_ID()) == 0) {
                    nonUnique = true;
                    break;
                }
            }
        }while (nonUnique);

        return acc_id;

    }

    /**
     * Add an account
     * @param anAcct   the account to add
     */

    public void addAccount(Account anAcct) {
        this.accounts.add(anAcct);
    }

    /**
     * Create a new user of the bank
     * @param firstName   the user's first name
     * @param lastName    the user's last name
     * @param pin         the user's pin
     * @return            the new User object
     */

    public User addUser(String firstName, String lastName, String pin ) {

        // create a new User object and add it to our list
        User newUser = new User(firstName, lastName, pin, this);
        this.users.add(newUser);

        //create a savings account for the user and bank accounts lists
        Account newAccount = new Account("Savings", newUser, this);
        newUser.addAccount(newAccount);
        this.accounts.add(newAccount);

        return newUser;
    }

    public User userLogin(String userID, String pin) {

        // search through list of users
        for (User u : this.users){

            // check user ID is correct
            if(u.getUNI_ID().compareTo(userID) == 0 && u.validatePin(pin)) {
                return u;
            }
        }
        // if we haven't found the user or have an incorrect pin
        return null;

    }

    /**
     * Get the name of the bank
     * @return  the name of the bank
     */
    public String getName() {
        return this.name;
    }

}
